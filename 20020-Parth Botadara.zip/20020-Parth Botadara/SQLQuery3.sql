Select * Into duplic_tb From temp_2 Where 1 = 2
select * from duplic_tb


create table product(
product_id int,
product_name varchar(20),
product_stock int
)

create table selling(
s_id int primary key identity(1,1),
s_name varchar(20),
s_stock int
)

drop table selling
alter table selling 
add s_id int primary key 

-- ALTER TABLE selling alter column s_id  INT NOT NULL PRIMARY KEY IDENTITY(1,1)

insert into product values(1,'Apple',10)
insert into product values(2,'Orange',50)
insert into product values(3,'Grapes',100)

select max(salary) from temp_2 group by temp_2.gend


