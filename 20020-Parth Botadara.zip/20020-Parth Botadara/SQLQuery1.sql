declare  @start int = 1,@end int = 10, @num int = 5
while @start <= @end
begin
	print (Concat(@num , ' * ' , @start , ' = '  , @start*@num))
set @start += 1
end






declare  @start int = 1,@end int = 10, @num int = 1
while @start <= @end
begin
	print (Concat(@num , ' * ' , @start , ' = '  , @start*@num))
set @start += 1
if @start=11
begin 
if @num=11
	break
set @start = 1 
set @num= @num+1
end
end






select round(rand()*100,0)

