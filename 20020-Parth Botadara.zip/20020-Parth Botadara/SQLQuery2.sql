create table temp(
id int , 
u_name  varchar(60),
city_name varchar(20),
phone_num numeric(20),
salary int,
age tinyint 


)
insert into temp values (1,'saawan','ahmedabad',9865321475,55555,25)
insert into temp values (2,'saa','delhi',9865321475,55555,25)
select * from temp


update temp set age=35 where id=1

WITH CTE AS
(
SELECT *,ROW_NUMBER() OVER (PARTITION BY id ,city_name ORDER BY id ,city_name) RN  FROM temp
)
DELETE FROM CTE WHERE RN<>1


create table temp_2 (
id int , 
u_name  varchar(60),
salary int,
gend varchar(10)

)

select * from temp_2
drop table temp_2
alter table temp_2
add gend varchar(10)
insert into temp_2 values (1,'saawan',25100,'male')
insert into temp_2 values (1,'Kanhaiya',20000,'male')
insert into temp_2 values (1,'Rahul',20100,'male')
insert into temp_2 values (1,'Hetasvi',30000,'female')
insert into temp_2 values (1,'Ankit',20056,'male')
insert into temp_2 values (1,'Hirva',26000,'female')
insert into temp_2 values (2,'saawan',26000,'male')

select MAX(salary)from temp_2

select *from temp_2 where salary=(select Max(salary) from temp_2);
select *from temp_2 
order by  salary desc 



select * from temp_2 where salary = (SELECT MAX(SALARY) FROM temp_2 WHERE SALARY < (SELECT MAX(SALARY) FROM temp_2))


SELECT TOP 50 PERCENT * FROM temp_2 order by salary desc



select * from temp_2