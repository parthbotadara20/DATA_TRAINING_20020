


select * from temp_2 where salary=( select max(salary) from temp_2 group by gend )


alter procedure sp_highsalary
@gender varchar(10) = null
as
begin 
select top 1 * from temp_2
where gend = @gender or @gender is null
order by salary desc
end

exec sp_highsalary 'male'



select top 1 * from temp_2
where gend = 'female'
order by salary desc



alter procedure fruits 
@fruit_name varchar(20),
@quentity int
as
begin
update product set product_stock=product_stock-@quentity where product_name=@fruit_name
insert into selling (s_name,s_stock) values (@fruit_name,@quentity) 
select * from product
select * from selling
end

exec fruits 'apple' ,7

select * from product
update product set product_stock = 10   where product_name = 'apple'


select product_stock from product where product.product_stock>@quentity 



alter procedure fruits 
@fruit_name varchar(20),
@quentity int 
as
begin
declare @a int  = (select product_stock from product where product_name=@fruit_name)
if ((select product_stock from product  where product_name= @fruit_name) > @quentity ) 
begin 
	update product 
	set product_stock=product_stock-@quentity where product_name=@fruit_name
	insert into selling (s_name,s_stock) values (@fruit_name,@quentity) 
	select * from product
	select * from selling
end
else 
begin select 'Please enter Lower Quentity less then or equal  ' + cast(@a as varchar(20))
end
end
exec fruits 'orange' ,50

if ((select product_stock from product  where product_name= 'apple') != 0  ) 
begin select 'invalid' end